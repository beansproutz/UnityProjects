﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class paddlePlaySound : MonoBehaviour
{
    // For added audio hehe
    public AudioClip pongClip;
    AudioSource audioSource;

    void Start()
    {
        audioSource = GetComponent<AudioSource>();
    }

    void OnCollisionEnter2D(Collision2D collisionInfo)
    {
        GameObject obj = collisionInfo.gameObject;
        if (obj.CompareTag("paddle"))
            audioSource.PlayOneShot(pongClip, 0.3f);

    }
}
