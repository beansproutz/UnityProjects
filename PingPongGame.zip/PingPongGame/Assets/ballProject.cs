﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.UI;

public class ballProject : MonoBehaviour
{
    public float speed = 5.0f;
    private int direction;
    public Rigidbody2D ball;
    public int constantSpeed;
    public int player1score, player2score;
    private bool inPlay;
    public bool player1Scored, player2Scored;
    Vector2[] newDir =
    {
        new Vector2(2, 1),
        new Vector2(-2, 1)
    };

    public Text player1scoreText, player2scoreText, winnerMessage;
    public GameObject instructions;
    AudioSource audioSource;
    public AudioClip pingClip;

    public void Start()
    {
        System.Random random = new System.Random();
        direction = random.Next(-1, 2);
        if (direction == 0)
        {
            direction = 1;
        }

        inPlay = true;
        ball = GetComponent<Rigidbody2D>();

        instructions = GameObject.FindWithTag("instr");
        audioSource = GetComponent<AudioSource>();
    }

    public void Update()
    {
        var pos = transform.position;
        if (inPlay)
        {
            ball.velocity = constantSpeed * (ball.velocity.normalized);
        }
        else
            pos.x = pos.y = 0;

        // Check if someone won
        if (pos.x < -8.86f)
        {
            player1Scored = true;
            player2Scored = false;
            player1score++;

            inPlay = false;
        }
        else if (pos.x > 8.89f)
        {
            player1Scored = false;
            player2Scored = true;
            player2score++;

            inPlay = false;
        }

        if (Input.GetKey(KeyCode.Space))
        {
            inPlay = true;
            instructions.GetComponent<Text>().enabled = false;

            // If ball went past player 2, player 1 scored
            if (player1Scored)
                ball.AddForce(newDir[0]);

            // If ball went past player 1, player 2 scored
            else if (player2Scored)
                ball.AddForce(newDir[1]);

            // Otherwise the game should start with rand direction
            else
                ball.AddForce(new Vector2(direction, direction));
        }

        transform.position = pos;
        if (player1score >= 3)
        {
            winnerMessage.text = "Player 1 Wins!";
            inPlay = false;
            ball.Sleep();
        }

        if (player2score >= 3)
        {
            winnerMessage.text = "Player 2 Wins!";
            inPlay = false;
            ball.Sleep();
        }

        // Display results
        player1scoreText.text = "" + player1score;
        player2scoreText.text = "" + player2score;
    }

    void OnCollisionEnter2D(Collision2D collisionInfo)
    {
        // If you get stuck in a vertical bounce, pivot slightly to help player
        if (System.Math.Round(ball.velocity.x) <= 1 && System.Math.Round(ball.velocity.x) >= -1 || System.Math.Round(ball.velocity.y) == 0)
        {
            if (player1Scored)
            {
                ball.velocity = newDir[0]; // go right if the ball last hit the left paddle
            }
            if (player2Scored)
            {
                ball.velocity = newDir[1]; // go left if the ball last hit the right paddle
            }
        }

        GameObject obj = collisionInfo.gameObject;
        if (obj.CompareTag("walls"))
            audioSource.PlayOneShot(pingClip, 0.3f);

    }
}
