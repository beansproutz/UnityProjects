﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class movePlayer1 : MonoBehaviour
{
    private Rigidbody2D rb;
    public Vector2 vel;
    public float y = 0.5f;
    public float x = 10.0f;
    public float boundUp;
    public float boundDown;
   
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }
    // Update is called once per frame
    void Update()
    {
        vel = rb.velocity;
        if (Input.GetKey(KeyCode.L)) {
            vel.y = -x;
            vel.x = 0.0f;
        }

        if (Input.GetKey(KeyCode.P)) {
            vel.y = x;
            vel.x = 0.0f;
        }
        

        if (!Input.anyKey)
        {
            vel.y = 0.0f;
            vel.x = 0.0f;
        }
        rb.velocity = vel;
        
        var pos = transform.position;
        if (pos.y > boundUp)
        {
            pos.y = boundUp;
        }
        if (pos.y < boundDown)
        {
            pos.y = boundDown;
        }
        transform.position = pos;

    }
}